package test_tp1;

import java.io.*;
import java.net.Socket;
import java.nio.file.Path;

public class Client {
	private static Socket socket;
	private static String serverAddress;
	private static int port;
	private static DataInputStream in;
	private static DataOutputStream out;
	private static Path actualPath; // A enlever; va dans ClientHandler
	
	public static boolean validatePort(final int port) {
		if (port >= 5000 && port <= 5050) {
			return true;
		}
		return false;
	}
	
	// Source: https://stackoverflow.com/questions/5667371/validate-ipv4-address-in-java
	public static boolean validateIP(final String ip) {
		String PATTERN = "^((0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)\\.){3}(0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)$";
	    return ip.matches(PATTERN);
	}
	
	private static void printMessage(String message) {
		System.out.println(message);
	}
	
	private static String readLine() throws IOException {
		InputStreamReader streamReader = new InputStreamReader(System.in);
	    BufferedReader bufferedReader = new BufferedReader(streamReader);
	    return bufferedReader.readLine();
	}
	
	public static String initializeIP() throws IOException {
		printMessage("IP Adress of the Client: ");
	    String serverAdressToValidate = readLine();
		
		while (!validateIP(serverAdressToValidate)) {
			printMessage("Invalid IP Adress. Try again.");
			initializeIP();
		}
		return serverAdressToValidate;
	}
	
	public static int initializePort() throws IOException {
		printMessage("Port of the Client: ");
	    String portToValidate = readLine();
	    
		while (!validatePort(Integer.parseInt(portToValidate))) {
			printMessage("Invalid Port. Try again.");
			initializePort();
		}
		return Integer.parseInt(portToValidate);
	}
	
	public static void connectToServer() throws IOException {
		serverAddress = initializeIP();
		port = initializePort();
		socket = new Socket(serverAddress, port);
		in = new DataInputStream(socket.getInputStream());
		out = new DataOutputStream(socket.getOutputStream());
	}
	
	public static boolean validateCommand(String commandToValidate) {
		String[] valideCommands = {"cd", "ls", "mkdir", "upload", "download", "exit"};
		boolean result = false;
		String firstCommandWord = getFirstCommandWord(commandToValidate);
		for (String command : valideCommands) {
			if (firstCommandWord.equals(command)) {
				result = true;
			}
		}
		return result;
	}
	
	private static String getFirstCommandWord(String command) {
		if (command.contains(" "))
			return command.split(" ", 2)[0];
		return command;
	}
	

	private static String getSecondCommandWord(String command) {
		if (command.contains(" "))
			return command.split(" ", 2)[0];
		return null;
	}
	
	//celui-la va dans ClientHandler
	public static void makeDirectory(String folder) {
		if (new File(actualPath.resolve(folder).toString()).mkdirs())
			printMessage("Folder " + folder + " created.");
		else
			printMessage("Error. Folder " + folder + " could not be created.");
	}
	
	public static void exit(String command) {
		try {
			socket.close();
		} catch (IOException e) {
			printMessage("Error. Disconnection without success.");
		}
		printMessage("Success. Disconnection done.");
	}
	
	//celui-la va dans ClientHandler
	public static void executeAction(String command) {
		String firstCommand = getFirstCommandWord(command);
		String secondCommand = getSecondCommandWord(command);
		
		switch(firstCommand) {
		case "cd":
			break;
		case "ls":
			break;
		case "mkdir":
			makeDirectory(secondCommand);
			break;
		case "upload":
			break;
		case "download":
			break;
		case "exit":
			exit(command);
			break;
		}
		printMessage("Action of " + command + " done!\n");
	}
	
	public static void run() throws IOException {
		String command = "";
	    
	    do {
	    	printMessage("\nCommand: ");
	    	command = readLine();
	    	 if (validateCommand(command)) {
	    		 executeAction(command);
	    	 }
	    	 else printMessage("Invalid Command. Try again.");
	    } while (!command.equals("exit"));
	}
	
	public static void main(String[] args) throws Exception {
		connectToServer();
		System.out.format("Serveur lancé sur [%s:%d]", serverAddress, port);
		String helloMessageFromServer = in.readUTF();
		System.out.println(helloMessageFromServer);
		run();
	} // while de communication avec serveur
}
