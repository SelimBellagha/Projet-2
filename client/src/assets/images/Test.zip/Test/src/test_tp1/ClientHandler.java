package test_tp1;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.nio.file.Path;
public class ClientHandler extends Thread {
	private Socket socket;
	private int clientNumber;
	private Path actualPath;
	
	public ClientHandler(Socket socket, int clientNumber) {
		this.socket = socket;
		this.clientNumber = clientNumber;
		System.out.println("New connection with client#" + clientNumber + " at" + socket);
	}
	
	private static void printMessage(String message) {
		System.out.println(message);
	}
	
	public static boolean validateCommand(String commandToValidate) {
		String[] valideCommands = {"cd", "ls", "mkdir", "upload", "download", "exit"};
		boolean result = false;
		String firstCommandWord = getFirstCommandWord(commandToValidate);
		for (String command : valideCommands) {
			if (firstCommandWord.equals(command)) {
				result = true;
			}
		}
		return result;
	}
	
	private static String getFirstCommandWord(String command) {
		if (command.contains(" "))
			return command.split(" ", 2)[0];
		return command;
	}
	

	private static String getSecondCommandWord(String command) {
		if (command.contains(" "))
			return command.split(" ", 2)[0];
		return null;
	}
	
	public void makeDirectory(String folder) {
		if (new File(actualPath.resolve(folder).toString()).mkdirs())
			printMessage("Folder " + folder + " created.");
		else
			printMessage("Error. Folder " + folder + " could not be created.");
	}
	
	public void exit(String command) {
		try {
			socket.close();
		} catch (IOException e) {
			printMessage("Error. Disconnection without success.");
		}
		printMessage("Success. Disconnection done.");
	}
	
	public void executeAction(String command) {
		String firstCommand = getFirstCommandWord(command);
		String secondCommand = getSecondCommandWord(command);
		
		switch(firstCommand) {
		case "cd":
			break;
		case "ls":
			break;
		case "mkdir":
			makeDirectory(secondCommand);
			break;
		case "upload":
			break;
		case "download":
			break;
		case "exit":
			exit(command);
			break;
		}
		printMessage("Action of " + command + " done!\n");
	}
	
	public void run() {
		try {
			DataOutputStream out = new DataOutputStream(socket.getOutputStream());
			out.writeUTF("Hello from server - you are client#" + clientNumber);
		} catch (IOException e) {
			System.out.println("Error handling client# " + clientNumber + ": " + e);
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				System.out.println("Couldn't close a socket, what's going on?");
			}
			System.out.println("Connection with client# " + clientNumber+ " closed");
		}
	} // 95% du code ici; while de communication avec client
}